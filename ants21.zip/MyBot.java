import java.io.IOException;
import java.util.*;

/**
 * Starter bot implementation.
 */
public class MyBot extends Bot {
    /**
     * Main method executed by the game engine for starting the bot.
     *
     * @param args command line arguments
     * @throws IOException if an I/O error occurs
     */
    public static void main(String[] args) throws IOException {
        new MyBot().readSystemInput();
    }

    private List<Tile> assignedFood;
    private Map<Tile, List<Tile>> standingOrders = new HashMap<Tile, List<Tile>>();

    /**
     * For every ant check every direction in fixed order (N, E, S, W) and move it if the tile is
     * passable.
     */
    @Override
    public void doTurn() {
        try {
            // strategy 1st
            // find closest food source for each ant
            // sort by distance
            // assign food source to closest ant
            // again until all ants have a job to do

            // strategy 2nd
            // something with enemy's

            List<Tile> targetedTiles = new LinkedList<Tile>();
            List<Tile> antsDone = new LinkedList<Tile>();
            List<Tile> remainingAnts = new LinkedList<Tile>();

            Ants ants = getAnts();

            remainingAnts.addAll(ants.getMyAnts());

            updateEnemyVisited(10);
            updateVisited();

            Set<Tile> antsWithOrders = new HashSet<Tile>();
            antsWithOrders.addAll(standingOrders.keySet());

            for (Tile tile : antsWithOrders) {
                if (!ants.getMyAnts().contains(tile)) {
                    standingOrders.remove(tile);
                } else {
                    List<Tile> orders = standingOrders.get(tile);
                    standingOrders.remove(tile);

                    if (!orders.isEmpty()) {
                        Tile next = orders.get(0);
                        if (!targetedTiles.contains(next)) {
                            orders.remove(0);
                            ants.issueOrder(tile, getDirection(tile, next));
                            targetedTiles.add(next);
                            standingOrders.put(next, orders);
                            remainingAnts.remove(tile);
                        }
                    }
                }
            }

            Set<Tile> foods = new HashSet<Tile>();
            foods.addAll(ants.getFoodTiles());

            // remove already targeted tiles from list
            for (Tile food : ants.getFoodTiles()) {
                for (Tile tile : standingOrders.keySet()) {
                    List<Tile> orders = standingOrders.get(tile);

                    if (!orders.isEmpty() && orders.get(orders.size() - 1).equals(food)) {
                        foods.remove(food);
                    }
                }
            }

            for (Tile food : foods) {
                if (ants.getTimeRemaining() > 100) {
                    Tile ant = findClosestAntWithinViewingDistance(remainingAnts, food);

                    if (ant != null) {
                        List<Tile> path = findShortestPath(ant, food);

                        if (!path.isEmpty() && path.size() < ants.getViewRadius2()) {
                            List<Tile> orders = new LinkedList<Tile>();
                            orders.addAll(path);
                            Tile first = orders.get(0);
                            if (!targetedTiles.contains(first)) {
                                orders.remove(0);
                                ants.issueOrder(ant, getDirection(ant, first));
                                targetedTiles.add(first);
                                remainingAnts.remove(ant);
                                standingOrders.put(first, orders);
                            }
                        }
                    }
                }
            }

            for (Tile myAnt : remainingAnts) {
                if (!antsDone.contains(myAnt) && ants.getTimeRemaining() > 10) {
                    boolean done = false;

                    if (!done) {
                        List<Tile> sortByLeastVisited = getNeighborsByLeastVisited(myAnt);

                        for (Tile targetedTile : sortByLeastVisited) {
                            Aim aim = getDirection(myAnt, targetedTile);
                            if (aim != null && ants.getIlk(myAnt, aim).isPassable() && !targetedTiles.contains(targetedTile) && ants.getIlk(myAnt, aim).isUnoccupied()) {
                                ants.issueOrder(myAnt, aim);
                                targetedTiles.add(targetedTile);
                                antsDone.add(myAnt);
                                done = true;
                                break;
                            }
                        }

                        int attempts = 0;
                        while (attempts < 10 && !done) {
                            attempts++;
                            Aim direction = getRandomDirection();
                            Tile targetedTile = ants.getTile(myAnt, direction);
                            Ilk ilk = ants.getIlk(myAnt, direction);
                            if (!targetedTiles.contains(targetedTile) && ilk.isPassable() && ilk.isUnoccupied()) {
                                ants.issueOrder(myAnt, direction);
                                targetedTiles.add(targetedTile);
                                antsDone.add(myAnt);
                                done = true;
                            }
                        }
                    }

                    if (!done) {
                        for (Aim direction : Aim.values()) {
                            Tile targetedTile = ants.getTile(myAnt, direction);
                            Ilk ilk = ants.getIlk(myAnt, direction);
                            if (!targetedTiles.contains(targetedTile) && ilk.isPassable() && ilk.isUnoccupied()) {
                                ants.issueOrder(myAnt, direction);
                                targetedTiles.add(targetedTile);
                                antsDone.add(myAnt);
                                break;
                            }
                        }
                    }
                }
            }
        } catch (Throwable t) {
            t.printStackTrace(System.err);
            throw new IllegalStateException(t);
        }
    }

    private Aim getDirection(Tile t1, Tile t2) {
        for (Aim aim : Aim.values()) {
            if (getAnts().getTile(t1, aim).equals(t2)) {
                return aim;
            }
        }

        return null;
    }

    public void showStandingOrders() {
        Set<Tile> antsWithOrders = standingOrders.keySet();

        for (Tile tile : antsWithOrders) {
            List<Tile> orders = standingOrders.get(tile);

            System.err.println("Orders Ant: " + tile);

            for (Tile t : orders) {
                System.err.println("\t" + t);
            }
        }
    }


}

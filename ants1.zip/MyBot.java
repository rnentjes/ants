import java.io.IOException;
import java.util.Random;

/**
 * Starter bot implementation.
 */
public class MyBot extends Bot {
    /**
     * Main method executed by the game engine for starting the bot.
     * 
     * @param args command line arguments
     * 
     * @throws IOException if an I/O error occurs
     */
    public static void main(String[] args) throws IOException {
        new MyBot().readSystemInput();
    }

    private Random r = new Random(System.currentTimeMillis());
    /**
     * For every ant check every direction in fixed order (N, E, S, W) and move it if the tile is
     * passable.
     */
    @Override
    public void doTurn() {
        Ants ants = getAnts();
        for (Tile myAnt : ants.getMyAnts()) {
            int attempts = 0;
            boolean done = false;
            while (attempts < 10 && !done) {
                Aim aim = getRandomDirection();

                if (ants.getIlk(myAnt, aim).isPassable()) {
                    ants.issueOrder(myAnt, aim);
                    done = true;
                }

                if (!done) {
                    for (Aim direction : Aim.values()) {
                        if (ants.getIlk(myAnt, direction).isPassable()) {
                            ants.issueOrder(myAnt, direction);
                            break;
                        }
                    }
                }
            }
        }
    }

    private Aim getRandomDirection() {
        Aim result = null;

        int i = r.nextInt(4);

        switch (i) {
            case 0:
                result = Aim.NORTH;
                break;
            case 1:
                result = Aim.NORTH;
                break;
            case 2:               result = Aim.NORTH;
                break;
            case 3:
                result = Aim.NORTH;
                break;
            default:
                throw new IllegalStateException("Impossible value!");

        }

        return result;
    }
}

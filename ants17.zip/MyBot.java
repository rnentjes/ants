import java.io.IOException;
import java.util.*;

/**
 * Starter bot implementation.
 */
public class MyBot extends Bot {
    /**
     * Main method executed by the game engine for starting the bot.
     *
     * @param args command line arguments
     * @throws IOException if an I/O error occurs
     */
    public static void main(String[] args) throws IOException {
        new MyBot().readSystemInput();
    }

    private Random r = new Random(System.currentTimeMillis());
    private List<Tile> assignedFood;
    private Map<Tile, Integer> visited = new HashMap<Tile, Integer>();

    /**
     * For every ant check every direction in fixed order (N, E, S, W) and move it if the tile is
     * passable.
     */
    @Override
    public void doTurn() {
        // strategy 1st
        // find closest food source for each ant
        // sort by distance
        // assign food source to closest ant
        // again until all ants have a job to do

        // strategy 2nd
        // something with enemy's

        List<Tile> targetedTiles = new LinkedList<Tile>();

        Ants ants = getAnts();
        for (Tile myAnt : ants.getMyAnts()) {
            Integer v = visited.get(myAnt);

            if (v == null) {
                visited.put(myAnt, 1);
            } else {
                visited.put(myAnt, v+1);
            }

            boolean done = false;

            List<Tile> sortByLeastVisited = getNeighborsByLeastVisited(myAnt);

            for (Tile targetedTile : sortByLeastVisited) {
                Aim aim = getDirection(myAnt, targetedTile);
                    if (aim != null && ants.getIlk(myAnt, aim).isPassable() && !targetedTiles.contains(targetedTile) && ants.getIlk(myAnt, aim).isUnoccupied()) {
                        ants.issueOrder(myAnt, aim);
                        targetedTiles.add(targetedTile);
                        done = true;
                        break;
                }
            }

            int attempts = 0;
            while (attempts < 10 && !done) {
                attempts++;
                Aim direction = getRandomDirection();
                Tile targetedTile =  ants.getTile(myAnt, direction);
                Ilk ilk = ants.getIlk(myAnt, direction);
                if (!targetedTiles.contains(targetedTile) && ilk.isPassable() && ilk.isUnoccupied()) {
                    ants.issueOrder(myAnt, direction);
                    targetedTiles.add(targetedTile);
                    done = true;
                }
            }

            if (!done) {
                for (Aim direction : Aim.values()) {
                    Tile targetedTile =  ants.getTile(myAnt, direction);
                    Ilk ilk = ants.getIlk(myAnt, direction);
                    if (!targetedTiles.contains(targetedTile) && ilk.isPassable() && ilk.isUnoccupied()) {
                        ants.issueOrder(myAnt, direction);
                        targetedTiles.add(targetedTile);
                        break;
                    }
                }
            }
        }
    }

    private Aim getDirection(Tile t1, Tile t2) {
        for (Aim aim : Aim.values()) {
            if (getAnts().getTile(t1, aim).equals(t2)) {
                return aim;
            }
        }
    }


    private List<Tile> getNeighborsByLeastVisited(Tile myAnt) {
        Ants ants = getAnts();

        Tile tileN = ants.getTile(myAnt, Aim.NORTH);
        Tile tileE = ants.getTile(myAnt, Aim.EAST);
        Tile tileS = ants.getTile(myAnt, Aim.SOUTH);
        Tile tileW = ants.getTile(myAnt, Aim.WEST);

        List<Tile> result = new LinkedList<Tile>();

        result.add(tileN);
        result.add(tileS);
        result.add(tileE);
        result.add(tileW);

        Collections.sort(result, new Comparator<Tile>() {
            public int compare(Tile o1, Tile o2) {
                Integer c1 = visited.get(o1);
                Integer c2 = visited.get(o2);

                if (c1 != null && c2 != null) {
                    return c1.compareTo(c2);
                } else if (c1 != null) {
                    return -1;
                } else {
                    return 1;
                }
            }
        });

        return result;
    }

    private Tile getClosestFood() {
        //getAnts().getIlk();
        Ilk ilk;
        Tile tile = null;

        return tile;
    }

    private Aim getRandomDirection() {
        Aim result = null;

        int i = r.nextInt(4);

        switch (i) {
            case 0:
                result = Aim.NORTH;
                break;
            case 1:
                result = Aim.EAST;
                break;
            case 2:
                result = Aim.SOUTH;
                break;
            case 3:
                result = Aim.WEST;
                break;
            default:
                throw new IllegalStateException("Impossible value!");

        }

        return result;
    }
}

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Starter bot implementation.
 */
public class MyBot extends Bot {
    /**
     * Main method executed by the game engine for starting the bot.
     *
     * @param args command line arguments
     * @throws IOException if an I/O error occurs
     */
    public static void main(String[] args) throws IOException {
        new MyBot().readSystemInput();
    }

    private Random r = new Random(System.currentTimeMillis());
    private List<Tile> assignedFood;
    private List<Tile> targetedTiles;

    /**
     * For every ant check every direction in fixed order (N, E, S, W) and move it if the tile is
     * passable.
     */
    @Override
    public void doTurn() {
        // strategy 1st
        // find closest food source for each ant
        // sort by distance
        // assign food source to closest ant
        // again until all ants have a job to do

        // strategy 2nd
        // something with enemy's

        targetedTiles = new LinkedList<Tile>();

        int rows = getAnts().getRows();
        int cols = getAnts().getCols();

        Ants ants = getAnts();
        for (Tile myAnt : ants.getMyAnts()) {
            int attempts = 0;
            boolean done = false;
            
            while (attempts < 10 && !done) {
                attempts++;
                Aim aim = getRandomDirection();
                Tile targetedTile =  ants.getTile(myAnt, aim);

                if (ants.getIlk(myAnt, aim).isPassable() && !targetedTiles.contains(targetedTile) && ants.getIlk(myAnt, aim).isUnoccupied()) {
                    ants.issueOrder(myAnt, aim);
                    done = true;
                }
            }

            if (!done) {
                for (Aim direction : Aim.values()) {
                    Tile targetedTile =  ants.getTile(myAnt, direction);
                    Ilk ilk = ants.getIlk(myAnt, direction);
                    if (!targetedTiles.contains(targetedTile) && ants.getIlk(myAnt, direction).isPassable() && ants.getIlk(myAnt, direction).isUnoccupied()) {
                        ants.issueOrder(myAnt, direction);
                        break;
                    }
                }
            }

            targetedTiles.add(myAnt);
        }
    }

    private Tile getClosestFood() {
        //getAnts().getIlk();
        Ilk ilk;
        Tile tile = null;

        return tile;
    }

    private Aim getRandomDirection() {
        Aim result = null;

        int i = r.nextInt(4);

        switch (i) {
            case 0:
                result = Aim.NORTH;
                break;
            case 1:
                result = Aim.EAST;
                break;
            case 2:
                result = Aim.SOUTH;
                break;
            case 3:
                result = Aim.WEST;
                break;
            default:
                throw new IllegalStateException("Impossible value!");

        }

        return result;
    }
}

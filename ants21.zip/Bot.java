import java.util.*;

/**
 * Provides basic game state handling.
 */
public abstract class Bot extends AbstractSystemInputParser {
    private Ants ants;

    protected Map<Tile, Integer> visited = new HashMap<Tile, Integer>();
    protected Random r = new Random(System.currentTimeMillis());


    /**
     * {@inheritDoc}
     */
    @Override
    public void setup(int loadTime, int turnTime, int rows, int cols, int turns, int viewRadius2,
                      int attackRadius2, int spawnRadius2) {
        setAnts(new Ants(loadTime, turnTime, rows, cols, turns, viewRadius2, attackRadius2,
                spawnRadius2));
    }

    /**
     * Returns game state information.
     *
     * @return game state information
     */
    public Ants getAnts() {
        return ants;
    }

    /**
     * Sets game state information.
     *
     * @param ants game state information to be set
     */
    protected void setAnts(Ants ants) {
        this.ants = ants;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void beforeUpdate() {
        ants.setTurnStartTime(System.currentTimeMillis());
        ants.clearMyAnts();
        ants.clearEnemyAnts();
        ants.clearMyHills();
        ants.clearEnemyHills();
        ants.getFoodTiles().clear();
        ants.getOrders().clear();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addWater(int row, int col) {
        ants.update(Ilk.WATER, new Tile(row, col));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addAnt(int row, int col, int owner) {
        ants.update(owner > 0 ? Ilk.ENEMY_ANT : Ilk.MY_ANT, new Tile(row, col));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addFood(int row, int col) {
        ants.update(Ilk.FOOD, new Tile(row, col));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void removeAnt(int row, int col, int owner) {
        ants.update(Ilk.DEAD, new Tile(row, col));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addHill(int row, int col, int owner) {
        ants.updateHills(owner, new Tile(row, col));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void afterUpdate() {
    }

    protected Aim getRandomDirection() {
        Aim result = null;

        int i = r.nextInt(4);

        switch (i) {
            case 0:
                result = Aim.NORTH;
                break;
            case 1:
                result = Aim.EAST;
                break;
            case 2:
                result = Aim.SOUTH;
                break;
            case 3:
                result = Aim.WEST;
                break;
            default:
                throw new IllegalStateException("Impossible value!");

        }

        return result;
    }

    protected List<Tile> getNeighborsByLeastVisited(Tile myAnt) {
        Ants ants = getAnts();

        Tile tileN = ants.getTile(myAnt, Aim.NORTH);
        Tile tileE = ants.getTile(myAnt, Aim.EAST);
        Tile tileS = ants.getTile(myAnt, Aim.SOUTH);
        Tile tileW = ants.getTile(myAnt, Aim.WEST);

        List<Tile> result = new LinkedList<Tile>();

        result.add(tileN);
        result.add(tileS);
        result.add(tileE);
        result.add(tileW);

        Collections.sort(result, new Comparator<Tile>() {
            public int compare(Tile o1, Tile o2) {
                Integer c1 = visited.get(o1);
                Integer c2 = visited.get(o2);

                if (c1 != null && c2 != null) {
                    return c1.compareTo(c2);
                } else if (c1 == null && c2 == null) {
                    return (r.nextInt(5) - 2);
                } else if (c1 != null) {
                    return 1;
                } else {
                    return -1;
                }
            }
        });

        return result;
    }

    protected void updateEnemyVisited(int minimalArmy) {
        for (Tile enAnt : ants.getEnemyAnts()) {
            if (ants.getMyAnts().size() > minimalArmy) {
                Integer v = visited.get(enAnt);

                if (v != null) {
                    visited.put(enAnt, v - 1);
                }
            }
        }
    }

    protected void updateVisited() {
        for (Tile myAnt : ants.getMyAnts()) {
            Integer v = visited.get(myAnt);

            if (v == null) {
                visited.put(myAnt, 1);
            } else {
                visited.put(myAnt, v + 1);
            }
        }
    }

    public final class TileDistance {
        public Tile tile;
        public int distance;

        public TileDistance(Tile tile, int distance) {
            this.tile = tile;
            this.distance = distance;
        }
    }

    protected List<Tile> findShortestPath(Tile t1, Tile t2) {
        List<Tile> path = findShortestPath(new LinkedList<Tile>(), 0, t1, t2);

        if (!path.isEmpty()) {
            path.remove(path.size()-1);
        }
        
        return path;
    }

    protected List<Tile> findShortestPath(List<Tile> visited, int currentDepth, Tile t1, Tile t2) {
        List<Tile> result = new LinkedList<Tile>();

        //System.err.println("CD: "+currentDepth);

        if (currentDepth > 250) {
            return result;
        }

        List<Tile> candidates = new LinkedList<Tile>();
        for (Aim aim : Aim.values()) {
            Tile candidate = getAnts().getTile(t1, aim);

            if (ants.getIlk(candidate).isPassable() && !visited.contains(candidate)) {
                visited.add(candidate);
                candidates.add(candidate);
            }
        }

        sortByDistance(t2, candidates);

        for (Tile candidate : candidates) {
            if (candidate.equals(t2)) {
                result.add(candidate);

                return result;
            }

            List<Tile> restOfPath = findShortestPath(visited, ++currentDepth, candidate, t2);

            // found?
            if (!restOfPath.isEmpty() && restOfPath.get(restOfPath.size()-1).equals(t2)) {
                result.add(candidate);
                result.addAll(restOfPath);

                return result;
            }
        }

        return result;
    }

    protected void sortByDistance(final Tile target, List<Tile> candidates) {
        Collections.sort(candidates, new Comparator<Tile>() {
            public int compare(Tile o1, Tile o2) {
                Integer d1 = getAnts().getDistance(target, o1);
                Integer d2 = getAnts().getDistance(target, o2);

                return d1.compareTo(d2);
            }
        });
    }

    protected Tile findClosestAntWithinViewingDistance(List<Tile> candidates, Tile tile) {
        Tile result = null;
        List<Tile> withinDistance = new LinkedList<Tile>();

        for(Tile c : candidates) {
            if (ants.getDistance(tile, c) < ants.getViewRadius2()) {
                withinDistance.add(c);
            }
        }

        sortByDistance(tile, withinDistance);

        if (!withinDistance.isEmpty()) {
            result = withinDistance.get(0);
        }

        return result;
    }


}
